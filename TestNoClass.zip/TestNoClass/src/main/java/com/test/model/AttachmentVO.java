package com.test.model;

import lombok.Data;

@Data
public class AttachmentVO {
    private Long fileId;
    private String fileName;
}

